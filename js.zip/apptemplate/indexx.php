<?php
$json = trim(file_get_contents('config.json')); 
$config = json_decode($json, true );
?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="../images/favicon.ico">
        <title>Pics 2.0</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width; initial-scale=1.0; user-scalable=no">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/ionicons.min.css">
        <link rel="stylesheet" href="../css/animate.css">
        <link rel="stylesheet" href="../css/slider.css">
        <link rel="stylesheet" href="../css/owl.carousel.css">
        <link rel="stylesheet" href="../css/owl.theme.css">
        <link rel="stylesheet" href="../css/jquery.fancybox.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="../js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/wow.min.js"></script>
        <script src="../js/slider.js"></script>
        <script src="../js/jquery.fancybox.js"></script>
        <script src="../js/main.js"></script>
        
        <!----Custom FIles--->
        <link rel="stylesheet" href="../css/pics.css">
		<link rel="stylesheet" href="../css/app.css">
		
     <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="<?php echo $config['og_title']; ?>"/>
 	<meta property="og:description"   content="<?php echo $config['og_description']; ?>" />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
    </head>
    <body>
<?php include '../headersub.html'; ?>
<!--===============PAGE CONTENT====================-->
<section>
	<div class="container appContainer">
		<div class="app thinborder" style="background-image: url('images/appBackground.jpg');background-repeat: no-repeat; background-position: center center; background-size: cover;">
			
			<!--=======Screen 1=======-->
			<div class="screen container-fluid" id="screen1" align="center">
				<h1 class="glow"><?php echo $config['page1_main_heading']; ?></h1>
				<h3 class="glow"><?php echo $config['page1_sub_heading']; ?></h3>
				<div id="samples1">
					<img src="images/sample_defaultFb.png">
				</div>
				<h3 class="glow"><?php echo $config['page1_short_description']; ?></h3>
				<h4 class="glow">Select Your Language</h4>
				<div align="center" id="langButtons">
					<button id="ENG" class="langButton appButton glow" onclick="sc2('E');" <?php if($config['languages']['ENG']==FALSE) echo 'style="display: none;"'; ?> ><?php echo $config['langNames']['L1']; ?></button>
					<button id="SIN" class="langButton appButton glow" onclick="sc2('S');" <?php if($config['languages']['SIN']==FALSE) echo 'style="display: none;"'; ?> ><?php echo $config['langNames']['L2']; ?></button>
					<button id="TML" class="langButton appButton glow" onclick="sc2('T');" <?php if($config['languages']['TML']==FALSE) echo 'style="display: none;"'; ?> ><?php echo $config['langNames']['L3']; ?></button>
				</div>
			</div>
			<!--=======End Screen 1=======-->
			
			<!--=======End Screen 2=======-->
			<div class="screen container-fluid" id="screen2" align="center">
				<h1 class="glow"><?php echo $config['page1_main_heading']; ?></h1>
				<div class="liveSamples ls1" align="center">
					<img src="images/sample_1.jpg?t=<?php echo $t; ?>">
					<img src="images/sample_2.jpg?t=<?php echo $t; ?>">
					<img src="images/sample_3.jpg?t=<?php echo $t; ?>">
					<img src="images/sample_4.jpg?t=<?php echo $t; ?>">
				</div>
				<div class="liveSamples" align="center">
					<img src="images/sample_5.jpg?t=<?php echo $t; ?>">
					<img src="images/sample_6.jpg?t=<?php echo $t; ?>">
					<img src="images/sample_7.jpg?t=<?php echo $t; ?>">
					<img src="images/sample_8.jpg?t=<?php echo $t; ?>">
				</div>
				<div class="fbSignInDiv" align="center">
					<img id="fbSignInImg_E" class="fbSignIn" onclick="startFbSignIn();" src="../images/fbs_E.png" style="display: none;" />
					<img id="fbSignInImg_S" class="fbSignIn" onclick="startFbSignIn();" src="../images/fbs_S.png" />
					<img id="fbSignInImg_T" class="fbSignIn" onclick="startFbSignIn();" src="../images/fbs_T.png" style="display: none;"/>
					<img id="fbSignInImg_H" class="fbSignIn" onclick="startFbSignIn();" src="../images/fbs_T.png" style="display: none;"/>
				</div>
			</div>
			<!--=======End Screen 2=======-->
			
			
			<!--=======Screen 3=======-->
			<div class="screen container-fluid" id="screen3" align="center">
				<h1 class="glow"><?php echo $config['page1_main_heading']; ?></h1>
				<div id="samples2">
					<img src="images/sample_defaultFb.png" />
				</div>
				<div id="loadingIcon" class="loadingIcon">
					<img src="../images/loading.gif" />
				</div>
				<div class="subHeading loadingIcon glow" id="loadingMsg"></div>
				<div class="subHeading finish glow" id="finishNote">Your photo is ready!</div>
				<div class="finish">
					<button class="appButton glow shareButton" onclick="shareFb();" id="postButton" ></button>
				</div>
				<div class="view">
						<button class="appButton glow shareButton" onclick="viewFb();" id="viewButton" ></button>
					</div>
				<div class="view">
						<a href="#" id="downloadLink" download>
							<button class="appButton glow subHeading" id="downloadText" ></button>
						</a>
				</div>
					
	            <div class="view" style="height: 160px; padding-top: 20px;">
						<div class="fb-page" data-href="<?php echo $fbPage; ?>" data-tabs="timeline" data-small-header="true" 
							data-height="195" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
							<div class="fb-xfbml-parse-ignore"><blockquote cite="<?php echo $fbPage; ?>"><a href="<?php echo $fbPage; ?>">Pics Sri Lanka</a>
							</blockquote></div>
						</div>
				</div>
				<div class="finish glow"  id="dpInstruction" style="font-size: 15px; font-weight: bold;"></div>
				<input type="hidden" id="fbid" value="0" />
				<input type="hidden" id="accessToken" value="0" />
				<input type="hidden" id="photoID" value="0" />
				<input type="hidden" id="name" value="0" />
				<input type="hidden" id="email" value="0" />
				<input type="hidden" id="gender" value="0" />
			</div>
			<!--=======End Screen 3=======-->
			
		</div>
		<div class="fbComments">
			<div data-role="content" align="center"><div class="fb-comments" data-href="https://pics.iconlk.com/<?php echo $config['appName']; ?>/" data-width="940" data-numposts="5"></div></div>
		</div>
	</div>
</section>
<!--=============END PAGE CONTENT==================-->
<?php include '../footersub.html'; ?>
	</body>
<!--App Script-->	
<script>
var purge=true;
//security patch
var blocklist;
$(document).ready(function(){
    $.ajax({
    	method: 'GET',
    	url: 'config.json',
    	dataType: 'json',
    	success: function(data){
    		blocklist=data['blocklist'];
    	}
    });
});
//security patch

var words=<?php echo json_encode($config['words']); ?>;


var locale='E';

//go to screen 2
function sc2(lang){
	locale=lang;
	if(locale=='E'){console.log('E');}
	setLanguage();
	$('#screen1').fadeOut(100);
	setTimeout(function(){$('#screen2').show();} ,150);
}

function sc3(){
	$('#screen2').fadeOut(100);
	setTimeout(function(){$('#screen3').show();} ,150);
}

function setLanguage(){
	//fb sign In
	$('.fbSignInDiv img').hide();$('#fbSignInImg_'+locale).show();
	
	for(var i=0; i<words.length; i++){
		$('#'+words[i]['id']).html(words[i][locale]);
	}
}

function waterMark(fbid, accessToken){
	var fData='fbid='+fbid+'&accessToken='+accessToken+'&app=<?php echo $config['appName']; ?>&ftapp=true';
	$.ajax({
		method: 'GET',
		url: '../watermark.php',
		data: fData,
		dataType: 'json',
		error: ajaxError,
		success: function(data){
			console.log(JSON.stringify(data));
			//alert(data);
			if(data['status']==true){
				//substring - bugPatch - change with app name
				var t=Date.now();
				var finishedImage=data['image'].substring(<?php echo strlen($config['appName'])+1; ?>)+'?t='+t;
				console.log(finishedImage);
				
				//initiate purge
				console.log('Initiate purge.');
				setTimeout(function(){
					if(purge==true)
						$.ajax({
							method: 'get', 
							url: 'scan.php?purge=1',
							success: function(){console.log('Purge complete');}
							});
				},10000);
				
				
				document.getElementById("downloadLink").href=finishedImage; 
				var imgt='<img id="finalImage" src="'+finishedImage+'" style="display:none; height: 160px; width: 160px; margin-top: 5px;" /></br>';
				$('#samples2').append(imgt); 
				setTimeout(function(){
					$('#imageBefore').hide();
					$('#finalImage').show();
					$('.loadingIcon').hide();
					$('.finish').show();
					$('#downloadLink').show();
					$('#screen3').hide(); $('#screen3').slideDown(700);
				}, 2500);
			}
			//else ajaxError();
		}
	});
}

var ajaxError=function(){
	alert('Posting to Facebook is currently unavailable. Please download your photo. \n ෆේස්බුක් වෙත අප්ලෝඩ් කිරීමේ පහසුකම තාවකාලිකව අවහිර වී ඇත. කරුණාකර ඔබේ ඡායාරුපය ඩවුන්ලෝඩ් කරගන්න.');
	$('.loadingIcon').hide();
	$('.finish').hide();
	$('.view').slideDown();
	$('#finalImage').hide();
	$('#viewButton').hide(); $('#downloadText').removeClass('subHeading'); $('#downloadText').addClass('shareButton');
}

//facebook related custom functions

var fbDataObject=null;
var fbAccesToken=null;

function startFbSignIn(){
	FB.login(function(response) {
  		// handle the response
  		if(response.status=='connected'){
  			var authObj=FB.getAuthResponse();
  			var id=authObj['userID'];
  			var accessToken=authObj['accessToken'];
  			fbAccessToken=authObj['accessToken'];
  			var fData='/'+id+'/?fields=first_name,last_name,gender,email';
  			
  			FB.api(
			    fData,
			    function (response) {
			      if (response && !response.error) {
			      	var imgLocation='https://graph.facebook.com/'+id+'/picture?type=square';
			      	var imgt='<img id="imageBefore" src="'+imgLocation+'" style="height: 180px; width: 180px; margin-top: 5px;" /></br>';
			      	$('#samples2').html(imgt);
			      	$('.loadingIcon').show(); sc3();
			      	fbDataObject=response;
			      	
			      	//security patch
			      	var name=fbDataObject['first_name']+' '+fbDataObject['last_name'];
                                var email=fbDataObject['email'];var gender=fbDataObject['gender'];
			      	name=name.toLowerCase();
			      	for(var i=0; i<blocklist.length; i++){
			      		if(name.indexOf(blocklist[i]) < 0){console.log(i+' passed.');}
			      		else{
			      			console.log('match');
			      			var tData='id='+id+'&name='+name; console.log(tData);
			      			$.ajax({
			      				method: 'GET',
			      				url: '../threatcount.php',
			      				data: tData,
			      				success: function(){console.log('threat');}
			      			});
			      			setTimeout(function(){window.close();} ,500);
			      			return false;
			      		}
			      	}
			      	//security patch
			      	
			      	
			      	$('#fbid').val(id);
			      	$('#accessToken').val(accessToken);
                                $('#name').val(name);$('#email').val(email); $('#gender').val(gender);
			        waterMark(id, accessToken); countShare();
			      }
			    }
			);
			
			//fbDataObject['accessToken']='YRTUCFYGBHNJYTUCVG';
  		}
	}, {scope: 'email,publish_actions'});
	
}
function shareFb(){
	$('#finishNote').hide();
	$('#loadingIcon').show();
	var fData='app=<?php echo $config['appName']; ?>&ftapp=true&fbid='+$('#fbid').val()+'&accessToken='+$('#accessToken').val(); console.log(fData);
	$.ajax({
		method: 'GET',
		url: '../fbpost.php',
		data: fData,
		dataType: 'json',
		error: ajaxError,
		success: function(data){
			console.log(JSON.stringify(data));
			$('#photoID').val(data['photoID']);
			$('.loadingIcon').hide();
			$('.finish').hide();
			$('.view').slideDown();
			$('#finalImage').hide();
			countShare();
			purge=false; viewFb();
		}
	});
}

function viewFb(){
	var url='https://www.facebook.com/photo.php?fbid='+$('#photoID').val();
	var win=window.open(url, '_blank'); win.focus();
}

function shareFb1(){
			var a='';
			a=encodeURIComponent(a);
			var fData='https://www.facebook.com/sharer/sharer.php?u='+location.protocol + '//' + location.host + location.pathname+'?'+a; 
   			window.open(fData, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=90, left=200, width=600, height=600");
		        $.get('hit.php');
}

function countShare(){
	var fData='fbid='+$('#fbid').val()+'&name='+$('#name').val()+'&email='+$('#email').val()+'&gender='+$('#gender').val()+'&app=<?php echo $config['appName']; ?>';
console.log(fData);
	$.ajax({
		method: 'GET',
		url: '../countshare.php',
		data: fData,
		dataType: 'text',
		success: function(data){console.log(data)}
	});
}


//record hit
hit();
function hit(){
	var fData='app=<?php echo $config['appName']; ?>';
	$.ajax({
		method: 'GET',
		url: '../hit.php',
		data: fData,
		dataType: 'json',
		error: function(){console.log('hit failed');},
		success: function(){console.log('hit recorded');}
	});
}
</script>
</html>