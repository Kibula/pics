<?php

$dir=array("ajax", ".settings", "apptemplate", "css", "customize", "fonts", "images", "js", "less", "timer-html", "temp", "uploads");

if(in_array($_GET['username'], $dir) == TRUE || strlen($_GET['username']) < 4 || ctype_alnum($_GET['username']) == FALSE){
	$result = FALSE;
}
else{
	include '../../dbc.php';
	$uname=mysqli_real_escape_string($conn, $_GET['username']);
	
	$sql="SELECT `username` FROM `apps` WHERE `username` LIKE ?";
	$stmt=$conn->prepare($sql);
	$stmt->bind_param('s', $uname);
	$stmt->execute();
	
	$stmt->store_result();
	$num=$stmt->num_rows; 
	
	$result = ($num == 0 ? "TRUE" : "FALSE");
	
}

echo $result;

?>