
<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="../images/favicon.ico">
        <title>Checkout</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width; initial-scale=1.0; user-scalable=no">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/ionicons.min.css">
        <link rel="stylesheet" href="../css/animate.css">
        <link rel="stylesheet" href="../css/slider.css">
        <link rel="stylesheet" href="../css/owl.carousel.css">
        <link rel="stylesheet" href="../css/owl.theme.css">
        <link rel="stylesheet" href="../css/jquery.fancybox.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="../js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/wow.min.js"></script>
        <script src="../js/slider.js"></script>
        <script src="../js/jquery.fancybox.js"></script>
        <script src="../js/main.js"></script>
        
        <!----Custom FIles--->
        <link rel="stylesheet" href="../css/pics.css">
		<link rel="stylesheet" href="../css/app.css">
		<link rel="stylesheet" href="../css/forms.css">
		
   <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="Pics - Celebrate With Your Profile Picture"/>
 	<meta property="og:description"   content="Celebrate your special events with a cool profile picture." />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
	
	<!---2CO-->
	<script src="https://www.2checkout.com/static/checkout/javascript/direct.min.js"></script>
<style>

</style>
    </head>
    <body>
<?php include '../headersub.html'; ?>
<!--===============PAGE CONTENT====================-->

<section>
	<div class="container">
		<div class="col-md-8 col-sm-12">
		<h4>&nbsp;</h4>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Confirm Payment</h2>
			</div>
			
			<div class="panel-body">
				<table class="table">
					<tr>
						<th>Item</th>
						<th>Quantity</th>
						<th>Amount</th>
					</tr>
					<tr>
						<td>Pics App - <span id="plan">Basic</span></td>
						<td>1</td>
						<td>990.00 INR</td>
					</tr>
					<tr>
						<td></td>
						<td>Subtotal</td>
						<td>990.00 INR</td>
					</tr>
					<tr>
						<td></td>
						<td>Discount</td>
						<td>0.00 INR</td>
					</tr>
					<tr style="font-size: 18px;">
						<th></th>
						<th>Total</th>
						<th>990.00 INR</th>
					</tr>
				</table>
			</div>
			
			<div class="panel-body">
				<hr />
				<!--2CO-->
				<form action='https://www.2checkout.com/checkout/purchase' method='post'>
				<input type='hidden' name='sid' value='1303908' />
				<input type='hidden' name='mode' value='2CO' />
				<input type='hidden' name='li_0_type' value='product' />
				<input type='hidden' name='li_0_name' value='invoice123' />
				<input type='hidden' name='li_0_price' value='990.00' />
				<input type="hidden" name="currency_code" value="INR" />
				<input type='hidden' name='card_holder_name' value='Checkout Shopper' />
				<input type='hidden' name='street_address' value='123 Test Address' />
				<input type='hidden' name='street_address2' value='Suite 200' />
				<input type='hidden' name='city' value='Columbus' />
				<input type='hidden' name='state' value='OH' />
				<input type='hidden' name='zip' value='43228' />
				<input type='hidden' name='country' value='USA' />
				<input type='hidden' name='email' value='example@2co.com' />
				<input type='hidden' name='phone' value='614-921-2450' />
				<div><input class="btn btn-lg btn-success rightIndicator" name='submit' type='submit' value='Checkout' /></div>
				
				</form>
				<!--2CO-->
			</div>
			<div class="panel-body" align="right">
				<hr />
					<a id="2COH" href="https://www.2checkout.com"><img src="https://www.2checkout.com/upload/images/paymentlogoshorizontal.png" alt="2Checkout.com is a worldwide leader in online payment services" /></a>
					<a id="2COV" style="display: none;" href="https://www.2checkout.com"><img src="https://www.2checkout.com/upload/images/paymentlogosvertical.png" alt="2Checkout.com is a worldwide leader in online payment services" /></a>
					<p>Secure online payments provided by <a href="https://www.2checkout.com">2Checkout</a></p>
			</div>
		</div>
		</div>
	</div>
	<h1>&nbsp;</h1>
</section>
<script>
/*
 * VALIDATION JS CODE
 */
//$('#pwdno').show(); $('#pwdno').scrollIntoView();
//$('#pwdweak').show(); $('#pwdweak').scrollIntoView();

var pwconf=false;
function pwd1(){
	var pwd=$('#password').val();if(pwd.length<8)$('#pwdweak').show();else $('#pwdweak').hide();
	if(pwconf==true) pwd2();
}
function pwd2(){
	var pwd=$('#password').val();var pwdx=$('#password2').val();
	if(pwd === pwdx){$('.tip').hide(); $('#pwdok').show();}
	else {$('.tip').hide(); $('#pwdno').show();}
	pwconf=true;
}
</script>
<!--=============END PAGE CONTENT==================-->
<?php include '../footersub.html'; ?>
	</body>

</html>