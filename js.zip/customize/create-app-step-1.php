
<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="../images/favicon.ico">
        <title>Create a PICS App</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width; initial-scale=1.0; user-scalable=no">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/ionicons.min.css">
        <link rel="stylesheet" href="../css/animate.css">
        <link rel="stylesheet" href="../css/slider.css">
        <link rel="stylesheet" href="../css/owl.carousel.css">
        <link rel="stylesheet" href="../css/owl.theme.css">
        <link rel="stylesheet" href="../css/jquery.fancybox.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="../js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/wow.min.js"></script>
        <script src="../js/slider.js"></script>
        <script src="../js/jquery.fancybox.js"></script>
        <script src="../js/main.js"></script>
        
        <!----Custom FIles--->
        <link rel="stylesheet" href="../css/pics.css">
		<link rel="stylesheet" href="../css/app.css">
		
   <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="Pics - Celebrate With Your Profile Picture"/>
 	<meta property="og:description"   content="Celebrate your special events with a cool profile picture." />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
<style>
.customizeContent{font-family:  !important;}
.customizeContent h2, .customizeContent p{font-family: ;}
.customizeContent p{font-size: 20px;}
.customizeContent ul li{font-size: 18px;}
.customizeContent ul li{list-style: square !important; list-style-position: inside;}

input, button{margin-top: 20px;}
button{float: right;}

hr{margin-bottom: 0px;}
i{font-size: 32px;	vertical-align: middle; margin-right: 20px;}
.alert {font-size: 16px;}
</style>
    </head>
    <body>
<?php include '../headersub.html'; ?>
<!--===============PAGE CONTENT====================-->

<section>
	<div class="container">
		<div class="col-md-8 col-sm-12">
		<h4>&nbsp;</h4>
		<div style="display: <?php echo (isset($_GET['duplicatemail']) ? 'block': 'none'); ?>;" class="alert alert-danger">
			<i class="ion-information-circled"></i> <strong>This email addres is already registered.</strong>
		</div>
		<div style="display: <?php echo (isset($_GET['invalidinput']) ? 'block': 'none'); ?>;" class="alert alert-danger">
			<i class="ion-information-circled"></i> <strong>Invalid Input.</strong>
		</div>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Add Your Info</h4>
				<span>Step 1 of 5</span>
			</div>
			<div class="panel-body">
				<form method="post" action="create-app-step-2.php">
					<input required class="form-control" name="name" id="name" />
					<label for="name">Your Name</label>
					
					<input required type="email" class="form-control" name="email" id="email" />
					<label for="email">Your Email</label>
					<br /><hr />
					<button type="submit" class="btn btn-lg btn-success">NEXT</button>
				</form>
			</div>
		</div>
		</div>
	</div>
</section>
<!--=============END PAGE CONTENT==================-->
<?php include '../footersub.html'; ?>
	</body>

</html>