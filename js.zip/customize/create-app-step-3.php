<?php
session_start();
if(!isset($_POST['eventName'])) header("Location: create-app-step-1.php?incompleteinput=JGKRXYBONKNFYTKVFYTV");
else {
	$eventName=$_POST['eventName'];
	$startDate=$_POST['startDate'];
	$endDate=$_POST['endDate'];
	if(ctype_alnum(str_replace(' ', '', $eventName)) === TRUE && strtotime($startDate) != FALSE && strtotime($endDate) != FALSE){
		$_SESSION['user']['eventName']=$eventName;
		$_SESSION['user']['startDate']=$startDate;
		$_SESSION['user']['endDate']=$endDate;
	}
	else header("Location: create-app-step-2.php?incompleteinput=HJKVKYUIRITFTFJFDERDIUHLYGYGYGT");
	
}
?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="../images/favicon.ico">
        <title>Create a PICS App</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width; initial-scale=1.0; user-scalable=no">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/ionicons.min.css">
        <link rel="stylesheet" href="../css/animate.css">
        <link rel="stylesheet" href="../css/slider.css">
        <link rel="stylesheet" href="../css/owl.carousel.css">
        <link rel="stylesheet" href="../css/owl.theme.css">
        <link rel="stylesheet" href="../css/jquery.fancybox.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="../js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/wow.min.js"></script>
        <script src="../js/slider.js"></script>
        <script src="../js/jquery.fancybox.js"></script>
        <script src="../js/main.js"></script>
        
        <!----Custom FIles--->
        <link rel="stylesheet" href="../css/pics.css">
		<link rel="stylesheet" href="../css/app.css">
		<link rel="stylesheet" href="../css/forms.css">
		
   <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="Pics - Celebrate With Your Profile Picture"/>
 	<meta property="og:description"   content="Celebrate your special events with a cool profile picture." />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
<style>

</style>
    </head>
    <body>
<?php include '../headersub.html'; ?>
<!--===============PAGE CONTENT====================-->

<section>
	<div class="container">
		<div class="col-md-8 col-sm-12">
		<h4>&nbsp;</h4>
		<div style="display: <?php echo (isset($_GET['incompleteinput']) ? 'block': 'none'); ?>;" class="alert alert-danger">
			<i class="ion-information-circled"></i> <strong>Incomplete Input.</strong>
		</div>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Setup App Details</h4>
				<span>Step 3 of 4</span>
			</div>
			<div class="panel-body">
				<form method="post" action="create-app-step-4.php">
					<input onblur="unamecheck();" onkeyup="$('#unamePreview').html(this.value);" required class="form-control" name="username" id="username" />
					<label for="name">App Username</label>
					<p>Username will be used to create your app URL. You app URL will be as follows.</p>
					<div class="well" >
						<strong style="font-size: 18px;">https://pics.iconlk.com/<span id="unamePreview">username</span></strong>
						<img class="rightIndicator loading" src="../images/loading.gif" />
						<p id="unameok" class="tip text-success"><i class="ion-android-checkmark-circle"></i>Username Available</p>
						<p id="unameno" class="tip text-danger"><i class="ion-android-cancel"></i>Username Unavailable</p>
					</div>
					<h3>&nbsp;</h3>
					
					<input required type="text" class="form-control" name="appName" id="appName" />
					<label for="email">Display Name of the App</label>
					
					<input onkeyup="pwd1();" required type="password" class="form-control" name="password" id="password" />
					<label for="email">Create Password</label>
					
					<input onkeyup="pwd2();" required type="password" class="form-control" name="password2" id="password2" />
					<label for="email">Re-enter Password</label>
					<p id="pwdok" class="tip text-success"><i class="ion-android-checkmark-circle"></i>Passwords Match</p>
					<p id="pwdno" class="tip text-danger"><i class="ion-android-cancel"></i>Passwords do not match</p>
					<p id="pwdweak" class="tip text-warning"><i class="ion-android-cancel"></i>Weak Password</p>
					
					<br /><hr />
					<button id="submit" type="submit" class="btn btn-lg btn-success">NEXT</button>
				</form>
			</div>
		</div>
		</div>
	</div>
	<h1>&nbsp;</h1>
</section>
<script>
/*
 * VALIDATION JS CODE
 */
//$('#pwdno').show(); $('#pwdno').scrollIntoView();
//$('#pwdweak').show(); $('#pwdweak').scrollIntoView();

varpwconf=false;
function pwd1(){
	var pwd=$('#password').val();if(pwd.length<8){$('#pwdweak').show(); $('button[type=submit]').prop('disabled', true); }else $('#pwdweak').hide();
	if(pwconf==true) pwd2();
}
function pwd2(){
	var pwd=$('#password').val();var pwdx=$('#password2').val();
	if(pwd === pwdx){$('.tip').hide(); $('#pwdok').show(); $('button[type=submit]').prop('disabled', false);}
	else {$('.tip').hide(); $('#pwdno').show(); $('button[type=submit]').prop('disabled', true);}
	pwconf=true;
}

/*
 * Live Username Check
 */

function unamecheck(){
	var uname=$('#username').val();
	$.ajax({
		url: 'ajax/usernamelivecheck.php',
		dataType: 'TEXT',
		data: 'username='+uname,
		error: function(){console.Error('Username live-check failed.'); alert('Something went wrong. This page will reload now.'); location.reload();},
		success: function(data){
			if(data == 'TRUE'){$('#unameok').show();$('#unameno').hide(); $('button[type=submit]').prop('disabled', false);}
			else {$('#unameno').show();$('#unameok').hide(); $('button[type=submit]').prop('disabled', true);}
		}
	});
}
</script>
<!--=============END PAGE CONTENT==================-->
<?php include '../footersub.html'; ?>
	</body>

</html>