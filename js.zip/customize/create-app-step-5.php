<?php
session_start();
if(!isset($_POST['title']) || !isset($_POST['subtitle']) || !isset($_POST['msg'])) header("Location: create-app-step-3.php?incompleteinput=JGKRXYBONKNFYTKVFYTV");
else {
	$title=htmlspecialchars($_POST['title']);
	$subtitle=htmlspecialchars($_POST['subtitle']);
	$message=htmlspecialchars($_POST['msg']);
	
	if(sizeof($title) > 0){
		$_SESSION['user']['title']=$title;
		$_SESSION['user']['subtitle']=$subtitle;
		$_SESSION['user']['message']=$message;
		
		$_SESSION['user']['lang']['E'] = (isset($_POST['E']) && $_POST['E'] == "on" ? TRUE : FALSE);
		$_SESSION['user']['lang']['H'] = (isset($_POST['H']) && $_POST['H'] == "on" ? TRUE : FALSE);
		$_SESSION['user']['lang']['S'] = (isset($_POST['S']) && $_POST['S'] == "on" ? TRUE : FALSE);
		$_SESSION['user']['lang']['T'] = (isset($_POST['T']) && $_POST['T'] == "on" ? TRUE : FALSE);
		
	}
	else header("Location: create-app-step-4.php?invalidinput=HJKVKYUIRITFTFJFDERDIUHLYGYGYGT");
}
?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="../images/favicon.ico">
        <title>Create a PICS App</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width; initial-scale=1.0; user-scalable=no">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/ionicons.min.css">
        <link rel="stylesheet" href="../css/animate.css">
        <link rel="stylesheet" href="../css/slider.css">
        <link rel="stylesheet" href="../css/owl.carousel.css">
        <link rel="stylesheet" href="../css/owl.theme.css">
        <link rel="stylesheet" href="../css/jquery.fancybox.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="../js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/wow.min.js"></script>
        <script src="../js/slider.js"></script>
        <script src="../js/jquery.fancybox.js"></script>
        <script src="../js/main.js"></script>
        
        <!----Custom FIles--->
        <link rel="stylesheet" href="../css/pics.css">
		<link rel="stylesheet" href="../css/app.css">
		<link rel="stylesheet" href="../css/forms.css">
		
   <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="Pics - Celebrate With Your Profile Picture"/>
 	<meta property="og:description"   content="Celebrate your special events with a cool profile picture." />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
<style>

</style>
    </head>
    <body>
<?php include '../headersub.html'; ?>
<!--===============PAGE CONTENT====================-->

<section>
	<div class="container">
		<div class="col-md-8 col-sm-12">
		<h4>&nbsp;</h4>
		<div style="display: <?php echo (isset($_GET['incompleteinput']) ? 'block': 'none'); ?>;" class="alert alert-danger">
			<i class="ion-information-circled"></i> <strong>Incomplete Input.</strong>
		</div>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Upload Artworks</h4>
				<span>Step 5 of 5</span>
			</div>
			<div class="panel-body">
				<form enctype="multipart/form-data" method="post" action="proceed-to-checkout.php">
					<div style="display: <?php echo (isset($_GET['incompleteimage']) ? 'block': 'none'); ?>;" class="alert alert-danger">Invalid image format or size. This image must be 720x720px PNG format.</div>
					<input required type="file" accept="image/x-png"  class="form-control" name="filter" id="filter" />
					<label for="name">Profile Picture Filter (720x720 png only)</label>
					
					<input type="file" accept="image/x-png, image/jpeg" class="form-control" name="background" id="background" />
					<label for="email">App Background Image (940x480 jpg)</label>
					
					<input type="file" accept="image/x-png, image/jpeg" class="form-control" name="promo" id="promo" />
					<label for="email">Promotional Image (1200x600 jpg)</label>
					
					<h2>&nbsp;</h2>
				
					
					<br /><hr />
					
					<button type="submit" class="btn btn-lg btn-success">Create My App</button>
					<image style="margin-top: 30px;" class="rightIndicator loading" src="../images/loading.gif" />
				</form>
			</div>
		</div>
		</div>
	</div>
	<h1>&nbsp;</h1>
</section>
<script>
/*
 * VALIDATION JS CODE
 */
//$('#pwdno').show(); $('#pwdno').scrollIntoView();
//$('#pwdweak').show(); $('#pwdweak').scrollIntoView();

var pwconf=false;
function pwd1(){
	var pwd=$('#password').val();if(pwd.length<8)$('#pwdweak').show();else $('#pwdweak').hide();
	if(pwconf==true) pwd2();
}
function pwd2(){
	var pwd=$('#password').val();var pwdx=$('#password2').val();
	if(pwd === pwdx){$('.tip').hide(); $('#pwdok').show();}
	else {$('.tip').hide(); $('#pwdno').show();}
	pwconf=true;
}
</script>
<!--=============END PAGE CONTENT==================-->
<?php include '../footersub.html'; ?>
	</body>

</html>