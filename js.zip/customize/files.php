<?php
//session_start();
$app=$_SESSION['user']['username'];
//copy files from template
recurse_copy("../apptemplate", "../".$app);

//load config
$json = trim(file_get_contents('../'.$app.'/config.json')); 
$config = json_decode($json, true );

//configure
$config['appName']=$app;
$config['page_title']=$config['og_title']=$_SESSION['user']['appName'];
$config['description']="Pics can help you to bring celebrating and promoting your events or organizations to a whole new level. We have a built in apps platform that lets your audience to change their social media display pictures with your watermark on it";
$config['og_description']="Get your new profile picture for ".$_SESSION['user']['eventName'];
$config['fb_comment_text']="Created with Pics Sri Lanka. Get your new profile picture for ".$_SESSION['user']['eventName'];
$config['fb_comment_link']="http://".$_SERVER["SERVER_NAME"]."/".$app;
$config['page1_main_heading']=$_SESSION['user']['title'];
$config['page1_sub_heading']=$_SESSION['user']['subtitle'];
$config['page1_short_description']=$_SESSION['user']['message'];
$config['languages']['ENG']=$_SESSION['user']['lang']['E'];
$config['languages']['SIN']=$_SESSION['user']['lang']['S'];
$config['languages']['TML']=$_SESSION['user']['lang']['T'];
$config['languages']['HIN']=$_SESSION['user']['lang']['H'];

//write json file
$fp = fopen('../'.$app.'/config.json', 'w');
fwrite($fp, json_encode($config));
fclose($fp);


/*
 * SAVE IMAGES
 */
 $filterPath='../'.$app.'/'.$app.'_filter.png';
 $backgroundPath='../'.$app.'/'.$app.'_background.jpg';
 $promoPath='../'.$app.'/'.$app.'_promo.jpg';
 $fbDefault=$promoPath='../'.$app.'/'.'fbDefault.jpg';
 
 $filterDest="../".$app."/images/wmk.png";
 $backgroundDest="../".$app."/images/appBackground.jpg";
 $promoDest="../".$app."/images/og_preview.jpg";
 $sampleDest="../".$app."/images/sample_defaultFb.png";
 
 
 /* SAVE FILTER */
$wmk = imagecreatefrompng($filterPath); //open
$imageHeight=intval(imagesy($wmk));
$imageWidth=intval(imagesx($wmk));
$temp = imagecreatetruecolor(720, 720);
imageAlphaBlending($temp, false);	//preserve alpha
imageSaveAlpha($temp, true);		//preserve alpha
imagecopyresized($temp, $wmk, 0, 0, 0, 0, 720, 720, $imageWidth, $imageHeight);
imagepng($temp, $filterDest); //store resized



 /* SAVE BACKGROUND */
 
if($images['b'] == TRUE){
	$bg = imagecreatefromjpeg($backgroundPath); //open
	$imageHeight=intval(imagesy($bg));
	$imageWidth=intval(imagesx($bg));
	$temp = imagecreatetruecolor(940, 480);
	imagecopyresized($temp, $bg, 0, 0, 0, 0, 940, 480, $imageWidth, $imageHeight);
	imagejpeg($temp, $backgroundDest); //store resized
}


 /* SAVE PROMO */
if($images['p'] == TRUE){
	$promo = imagecreatefromjpeg($promoPath); //open
	$imageHeight=intval(imagesy($promo));
	$imageWidth=intval(imagesx($promo));
	$temp = imagecreatetruecolor(1200, 600);
	imagecopyresized($temp, $promo, 0, 0, 0, 0, 1200, 600, $imageWidth, $imageHeight);
	imagejpeg($temp, $promoDest); //store resized
}


//release memory
imagedestroy($bg); imagedestroy($promo);


/* CREATE SAMPLES */

$im1 = imagecreatefromjpeg($fbDefault);
// Load the stamp and the photo to apply the watermark to
$stamp = imagecreatefrompng($filterPath);
// Set the margins for the stamp and get the height/width of the stamp image
$marge_right = 10;
$marge_bottom = 10;
$sx = imagesx($stamp);
$sy = imagesy($stamp);


// Merge the stamp onto our photo
imagecopymerge_alpha($im1, $stamp, imagesx($im1) - $sx, imagesy($im1) - $sy, 0, 0, imagesx($stamp), imagesy($stamp), 100);
//imagecopymerge($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($im)*20/100.0, imagesy($im)*20/100.0, 70);


//SAMPLE_DEFAULT
$temp1 = imagecreatetruecolor(250, 250);
imagecopyresampled($temp1, $im1, 0, 0, 0, 0, 250, 250, 720, 720);//resize
imagejpeg($temp1, $sampleDest, 100);
imagedestroy($temp1);

//MINI_SAMPLES
$temp2 = imagecreatetruecolor(120, 120);
imagecopyresampled($temp2, $im1, 0, 0, 0, 0, 120, 120, 720, 720);//resize
for($i=1; $i<9; $i++){
	$xpath="../".$app."/images/sample_".$i.".jpg";
	imagejpeg($temp2, $xpath, 100);
}

if($images['b'] == FALSE){
	//PROMO_DEFAULT
	$temp3 = imagecreatetruecolor(400, 400);
	imagecopyresampled($temp3, $im1, 0, 0, 0, 0, 400, 400, 720, 720);//resize
	imagejpeg($temp3, $promoDest, 100);
	imagedestroy($temp3);
}

//unlink($promoPath);
//unlink($filterPath);
//unlink($backgroundPath);

function recurse_copy($src,$dst) { 
    $dir = opendir($src); 
    @mkdir($dst); 
    while(false !== ( $file = readdir($dir)) ) { 
        if (( $file != '.' ) && ( $file != '..' )) { 
            if ( is_dir($src . '/' . $file) ) { 
                recurse_copy($src . '/' . $file,$dst . '/' . $file); 
            } 
            else { 
                copy($src . '/' . $file,$dst . '/' . $file); 
            } 
        } 
    } 
    closedir($dir); 
} 

//3rd party 
  function imagecopymerge_alpha($dst_im, $src_im, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct){ 
        // creating a cut resource 
        $cut = imagecreatetruecolor($src_w, $src_h); 

        // copying relevant section from background to the cut resource 
        imagecopy($cut, $dst_im, 0, 0, $dst_x, $dst_y, $src_w, $src_h); 
        
        // copying relevant section from watermark to the cut resource 
        imagecopy($cut, $src_im, 0, 0, $src_x, $src_y, $src_w, $src_h); 
        
        // insert cut resource to destination image 
        imagecopymerge($dst_im, $cut, $dst_x, $dst_y, 0, 0, $src_w, $src_h, $pct); 
    } 

?>