
<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="../images/favicon.ico">
        <title>Pics 2.0</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width; initial-scale=1.0; user-scalable=no">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/ionicons.min.css">
        <link rel="stylesheet" href="../css/animate.css">
        <link rel="stylesheet" href="../css/slider.css">
        <link rel="stylesheet" href="../css/owl.carousel.css">
        <link rel="stylesheet" href="../css/owl.theme.css">
        <link rel="stylesheet" href="../css/jquery.fancybox.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="../js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/wow.min.js"></script>
        <script src="../js/slider.js"></script>
        <script src="../js/jquery.fancybox.js"></script>
        <script src="../js/main.js"></script>
        
        <!----Custom FIles--->
        <link rel="stylesheet" href="../css/pics.css">
		<link rel="stylesheet" href="../css/app.css">
		
   <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="Pics - Celebrate With Your Profile Picture"/>
 	<meta property="og:description"   content="Celebrate your special events with a cool profile picture." />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
<style>
.customizeContent{font-family:  !important;}
.customizeContent h2, .customizeContent p{font-family: ;}
.customizeContent p{font-size: 20px;}
.customizeContent ul li{font-size: 18px;}
.customizeContent ul li{list-style: square !important; list-style-position: inside;}


</style>
    </head>
    <body>
<?php include '../headersub.html'; ?>
<!--===============PAGE CONTENT====================-->

<section>
	<div class="container customizeContent">
		<div class="row">
			<div class="col-md-6 col-sm-12">
				<h1 class="text-info">Get A PICS App to Promote Your Event/Business</h1>
				<p>Add a Pics app to promote your event in a new way. Get your community to change their Facebook profile pictures with your watermark on it! </p>		
				<p>Promote your business with a touch of creativity. Pics will help you expose your brand to new people. It's easy to setup, simple and affordable.</p>
				<h3>Features</h3>
				<ul>
					<li>Basic app setup with customizable interface</li>
					<li>App dashboard to control app activity</li>
					<li>Track generated & uploaded photo count & more statistics</li>
					<li>Embed your Facebook page widget into app. (Pro version)</li>
					<li>Embed app in to your website (Pro version)</li>
					<li>View your app users' public Facebook profile (Enterprise version)</li>
					<li>Send Facebook notifications to desktop users (Enterprise version)</li>
				</ul>
			</div>
			<div class="col-md-1">&nbsp;</div>
			<div class="col-md-5 col-sm-12" class="rightDiv">
				<div>
					<h1>&nbsp;</h1>
					<h1><button onclick="location.href='create-app-step-1.php';" style="width: 300px; height: 60px;" class="btn btn-warning btn-lg">Create My PICS App</button></h1>
				</div>
				<div align="left" style="margin-left: 30px;">
					<h3>Things To Prepare</h3>
					<ul>
						<li>
							Your filter design. (720x720px / png format)
							<p style="font-size: 14px;">This image will be added to the profile pictures taken from Facebook.</p>
						</li>
						<li>
							App background image. (9400x480px / jpg format)
							<p style="font-size: 14px;">This image will be in the background of the app interface.</p>
						</li>
						<li>
							Promotional image. (1200x600px / jpg format)
							<p style="font-size: 14px;">This image will appear on facebook link previews when users share your app link.</p>
						</li>
					</ul>
					
					<h3>Plans</h3>
					<ul>
						<li>Basic App - 990INR</li>
						<li>Pro App - 1290INR</li>
						<li>Enterprise App - 3290INR</li>
					</ul>
				</div>
			</div>
			<h1>&nbsp;</h1>
		</div>
		
	</div>
</section>
<!--=============END PAGE CONTENT==================-->
<?php include '../footersub.html'; ?>
	</body>

</html>