<?php
session_start(); $app=$_SESSION['user']['username'];
//var_dump($_SESSION);
//echo json_encode($_SESSION);
try {
    
    // Undefined | Multiple Files | $_FILES Corruption Attack
    // If this request falls under any of them, treat it invalid.
    if (!isset($_FILES['filter']['error']) || is_array($_FILES['filter']['error'])) {header("Location: create-app-step-5.php?incompleteimage=true");}

	$types=array();
	foreach ($_FILES as $key => $value) {
		if(strpos($_FILES[$key]['type'], "image/png") !== FALSE) $types[$key]='png';
		else if(strpos($_FILES[$key]['type'], "image/jpeg") !== FALSE) $types[$key]='jpg';
		else $types[$key]=FALSE;
	}

	//echo $_FILES['background']['error'];

	$images=array();
	if($_FILES['filter']['error'] == UPLOAD_ERR_NO_FILE ) $images['f']=FALSE; else $images['f']=TRUE;
	if($_FILES['background']['error'] == UPLOAD_ERR_NO_FILE ) $images['b']=FALSE; else $images['b']=TRUE;
	if($_FILES['promo']['error'] == UPLOAD_ERR_NO_FILE ) $images['p']=FALSE; else $images['p']=TRUE;

	//var_export($images);
	
    // Check $_FILES['upfile']['error'] value.
    /*foreach ($_FILES as $key => $value) {
	 * 
	 * 
	 * 
	 * 
    	switch ($_FILES[$key]['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            throw new RuntimeException('No file sent.');
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            throw new RuntimeException('Exceeded filesize limit.');
        default:
            throw new RuntimeException('Unknown errors.');
    	}  
		
		 // You should also check filesize here. 
	    if ($_FILES['filter']['size'] > 1000000) {
	        throw new RuntimeException('Exceeded filesize limit.');
	    }  
    }*/
    
	//create app directory
	$pathname="../".$_SESSION['user']['username'];  
	if (!file_exists($pathname)) {
		if(! mkdir($pathname, 0744, true)) echo "FAILED CREATING APP ";
	}
	else echo "APP USERNAME ALREADY EXISTS";
   
   	
	//move filter
   	if($_FILES['filter']['type'] == "image/png") 
   		move_uploaded_file($_FILES['filter']['tmp_name'], $pathname."/".$app."_filter.png");
	//else header("Location: Location: create-app-step-5.php?incompleteimage=true");
	
	
	//move bg
	if($_FILES['background']['error'] == 0 && $types['background'] != FALSE){
	 	move_uploaded_file($_FILES['background']['tmp_name'], $pathname."/".$app."_background.".$types['background']);
	}
	if($_FILES['promo']['error'] == 0 && $types['promo'] != FALSE){
	 	move_uploaded_file($_FILES['promo']['tmp_name'], $pathname."/".$app."_promo.".$types['promo']);
	}
   
   	//create app in database
   	$offText="This app has been temporary deactivated by the app coordinator. Please contact the app coordinator for your organization/event for more information.";
   	$fbPage = "http://"; $type="BASIC"; $one=1; $zero=0;
   	require '../dbc.php';
	$sql = "INSERT INTO `apps` 
		(`username`, `pwdHash`, `name`, 
		`description`, `ownerName`, `ownerEmail`,
		 `setupTime`,`eventStart`, `eventEnd`, 
		 `type`, `lastGraphCall`, `active`, 
		 `thumb`, `lastUser`, `on`, 
		 `offNote`, `fbPage`) 
		VALUES ( ?, ?, ?,    ?, ?, ?,   CURRENT_TIMESTAMP, ?, ?,   ?, CURRENT_TIMESTAMP, ?,  ?, ?, ?,     ?, ?);";
	$stmt=$conn->prepare($sql);
	$stmt->bind_param(
		"sssssssssiiiiss",
		$_SESSION['user']['username'],
		$_SESSION['user']['pwdHash'],
		$_SESSION['user']['appName'],
		
		$_SESSION['user']['title'], //description
		$_SESSION['user']['name'], //ownerName
		$_SESSION['user']['email'], //contact email
		//setupTime
		$_SESSION['user']['startDate'],
		$_SESSION['user']['endDate'],
		$type,
		
		$zero, //active
		$zero, //thumb
		$zero, //lastUser
		
		$one, //onOff status
		$offText, //offNote
		$fbPage
	);
	if($stmt->execute()){
		include 'files.php';
	}
	else{
		 echo " ERROR: Failed to create app. Please try again."; 
		 //echo mysqli_error($conn);
	}
   	
   	/*
	 * "name": "dfhndgfhesgtrsw",
		"email": "supunxml@outlook.com",
		"eventName": "srdthrrt",
		"startDate": "2016-07-06",
		"endDate": "2016-07-14",
		"username": "testapp123",
		"appName": "tdehjtheyhety",
		"pwdHash": "0d1ea4c256cd50a2a7ccbfd22b3d9959f6fd30bd840b9ff3c7c65ee4e21df06d",
		"title": "tjetjtujeuj",
		"subtitle": "etjjejjyu",
		"message": "etyjetyeje",
		"lang": {
			"E": true,
			"H": true,
			"S": false,
			"T": true
		}
	 * 
	 * /

    // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
    // Check MIME Type by yourself.
    /*$finfo = new finfo(FILEINFO_MIME_TYPE);
    if (false === $ext = array_search(
        $finfo->file($_FILES['filter']['tmp_name']),
        array(
            'jpg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
        ),
        true
    )) {
        throw new RuntimeException('Invalid file format.');
    }*/

    // You should name it uniquely.
    // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
    // On this example, obtain safe unique name from its binary data.
   /* if (!move_uploaded_file(
        $_FILES['filter']['tmp_name'],
        sprintf('./uploads/%s.%s',
            sha1_file($_FILES['filter']['tmp_name']),
            $ext
        )
    )) {
        throw new RuntimeException('Failed to move uploaded file.');
    }*/

    //echo 'File is uploaded successfully.';

} catch (RuntimeException $e) {

    echo $e->getMessage();

}

?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="../images/favicon.ico">
        <title>Checkout</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width; initial-scale=1.0; user-scalable=no">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/ionicons.min.css">
        <link rel="stylesheet" href="../css/animate.css">
        <link rel="stylesheet" href="../css/slider.css">
        <link rel="stylesheet" href="../css/owl.carousel.css">
        <link rel="stylesheet" href="../css/owl.theme.css">
        <link rel="stylesheet" href="../css/jquery.fancybox.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="../js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/wow.min.js"></script>
        <script src="../js/slider.js"></script>
        <script src="../js/jquery.fancybox.js"></script>
        <script src="../js/main.js"></script>
        
        <!----Custom FIles--->
        <link rel="stylesheet" href="../css/pics.css">
		<link rel="stylesheet" href="../css/app.css">
		<link rel="stylesheet" href="../css/forms.css">
		
   <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="Pics - Celebrate With Your Profile Picture"/>
 	<meta property="og:description"   content="Celebrate your special events with a cool profile picture." />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
<style>

</style>
    </head>
    <body>
<?php include '../headersub.html'; ?>
<!--===============PAGE CONTENT====================-->

<section>
	<div class="container">
		<div class="col-md-8 col-sm-12">
		<h4>&nbsp;</h4>
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="col-md-8 col-sm-12"><h1>Your App Has Been Created!</h1></div>
				<div class="col-md-4 col-sm-12"><button class="btn btn-lg btn-warning">Preview My App</button></div>
			</div>
			<hr />
			<div class="panel-body">
				<h3>Select Your Plan</h3>
				<form method="post" target="confirm-checkout.php">
					<label for="BASIC" class="col-md-4 col-sm-12 pricePlan">
						<div id="Bpanel" class="panel panel-default">
						<div class="panel-heading" align="center">
							<p>Basic App</p>
						</div>
						<div class="panel-body">
							<ul>
								<li>Basic app setup with customizable interface</li>
								<li>App dashboard to control app activity</li>
								<li>Track generated & uploaded photo count & more statistics</li>
							</ul>
							<div class="well pricewell" align="center">
								<h4 class="cut">1290.00 INR</h4>
								<h1 class="price">990.00 INR</h1>
							</div>
						</div>
						<div class="panel-footer" align="center">
							<input required onclick="$('#fbp').hide();$('.pricePlan .panel').removeClass('panel-success'); $('#Bpanel').addClass('panel-success');" class="form-control" type="radio" value="BASIC" name="plan" id="BASIC" />
						</div>
						</div>
					</label>
					
					<label for="PRO" class="col-md-4 col-sm-12 pricePlan">
						<div id="Ppanel" class="panel panel-default">
						<div class="panel-heading" align="center">
							<p>Pro App</p>
						</div>
						<div class="panel-body">
							<ul>
								<li>All basic app features</li>
								<li>Embed your Facebook page widget into app</li>
								<li>Embed app in to your website</li>
							</ul>
							<div class="well pricewell" align="center">
								<h4 class="cut">1490.00 INR</h4>
								<h2 class="price">1290.00 INR</h2>
							</div>
						</div>
						<div class="panel-footer" align="center">
							<input required onclick="$('#fbp').show();$('.pricePlan .panel').removeClass('panel-success'); $('#Ppanel').addClass('panel-success');" class="form-control" type="radio" value="PRO" name="plan" id="PRO" />
						</div>
						</div>
					</label>
					
					<label for="ENT" class="col-md-4 col-sm-12 pricePlan">
						<div id="Epanel" class="panel panel-default">
						<div class="panel-heading" align="center">
							<p>Enterprise App</p>
						</div>
						<div class="panel-body">
							<ul>
								<li>All pro app features</li>
								<li>View your app users' public Facebook profile</li>
								<li>Send Facebook notifications to desktop users</li>
							</ul>
							<div class="well pricewell" align="center">
								<h4 class="cut">3690.00 INR</h4>
								<h2 class="price">3290.00 INR</h2>
							</div>
						</div>
						<div class="panel-footer" align="center">
							<input required onclick="$('#fbp').show();$('.pricePlan .panel').removeClass('panel-success'); $('#Epanel').addClass('panel-success');" class="form-control" type="radio" value="ENT" name="plan" id="ENT" />
						</div>
						</div>
					</label>
					<div id="fbp" class="col-md-12">
						<hr />
						<h4>Please enter your Facebook Page URL below for Pro/Enterprise apps.</h4>
						<input class="form-control" type="url" name="fbpage" placeholder="Facebook Page URL"/>
						<hr />
					</div>
					
					<div>
						<button class="btn btn-lg btn-success">Proceed To Checkout</button>
					</div>
				</form>
			</div>
			
		</div>
		</div>
	</div>
	<h1>&nbsp;</h1>
</section>
<script>
/*
 * VALIDATION JS CODE
 */
//$('#pwdno').show(); $('#pwdno').scrollIntoView();
//$('#pwdweak').show(); $('#pwdweak').scrollIntoView();

var pwconf=false;
function pwd1(){
	var pwd=$('#password').val();if(pwd.length<8)$('#pwdweak').show();else $('#pwdweak').hide();
	if(pwconf==true) pwd2();
}
function pwd2(){
	var pwd=$('#password').val();var pwdx=$('#password2').val();
	if(pwd === pwdx){$('.tip').hide(); $('#pwdok').show();}
	else {$('.tip').hide(); $('#pwdno').show();}
	pwconf=true;
}
</script>
<!--=============END PAGE CONTENT==================-->
<?php include '../footersub.html'; ?>
	</body>

</html>