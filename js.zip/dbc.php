<?php

	//login credentials | Webhost
	$host_db = "localhost";
	$user_db = "etestlk_picsuser";
	$pword_db = "tVX?~)]F?9wE";
	$db = "etestlk_pics";

	//change login info if on local server
	//$serverList = array('localhost', '127.0.0.1');
	if($_SERVER['HTTP_HOST'] == 'localhost' || $_SERVER['HTTP_HOST'] == '127.0.0.1') {
		$host_db="localhost";
		$user_db="root";
		$pword_db="";
		$db="pics2";
	}
	
	//connect and select DB
	$conn =new mysqli($host_db,$user_db,$pword_db,$db) or die(mysqli_connect_error());	 
	
	//select chatacter set
	$conn->set_charset('utf8');   
	
	//set MySql TimeZone
	$sql="SET time_zone='+05:30';";
	$result=mysqli_query($conn, $sql);
	
	//set PHP timezone
	define('TIMEZONE', 'Asia/Colombo');
	date_default_timezone_set(TIMEZONE);
?>