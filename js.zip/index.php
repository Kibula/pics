<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="icon/ico" href="images/favicon.ico">
        <title>Pics 2.0</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Template CSS Files
        ================================================== -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/ionicons.min.css">
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="css/slider.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/owl.theme.css">
        <link rel="stylesheet" href="css/jquery.fancybox.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/responsive.css">
        
        <!-- Template Javascript Files
        ================================================== -->
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/slider.js"></script>
        <script src="js/jquery.fancybox.js"></script>
        <script src="js/main.js"></script>
        
        <!----Custom CSS--->
         <link rel="stylesheet" href="css/pics.css">
         
     <!--Facebook-->
	<meta property="og:url" content="<?php echo "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'] ?>"/>
 	<meta property="og:type"          content="website" />
 	<meta property="og:title" content="Pics - Celebrate With Your Profile Picture"/>
 	<meta property="og:description"   content="Celebrate your special events with a cool profile picture." />
	<meta property="og:image" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>images/og_preview.jpg"/>
	<meta property="og:image:width" content="1055" /><meta property="og:image:height" content="703" />
	<meta property="og:site_name" content="Pics - Celebrate With Your Profile Picture"/>
	
	<!--Facebook-->
    </head>
    <body>
<?php include 'header.html'; ?>
<!--===============PAGE CONTENT====================-->

   
            <!--
            ==================================================
            Portfolio Section Start
            ================================================== -->
            <section id="works" class="works">
                <div class="container">
                    <div class="section-heading">
                        <h1 class="title wow fadeInDown" data-wow-delay=".3s">Celebrate Your Special Moments in a New Way!</h1>
                        <p class="wow fadeInDown" data-wow-delay=".5s">
                            Add a special social media display picture to celebrate and promote your special event.<br/> Pics helps you to bring event promotion to a whole new level. Check out our app gallery and join the new trend.
                        </p>
                        <div align="center">
                        	<form id="searhForm">
                        		<div class="input-group add-on">
                        		 	<input class="form-control" placeholder="Search App" name="keyword" id="srch-term" type="text">
								    <div class="input-group-btn">
								        <button class="btn btn-default" type="submit"><i class="ion-ios-search"></i></button>
								    </div>
    							</div>
                        	</form>
                        	
                        </div>
                    </div>
                    <div class="row">
                    
                    <?php for($i=0; $i<12; $i++){ ?>
                    	<!--box-->
                        <div class="col-sm-3 col-xs-6">
                            <figure class="wow fadeInLeft animated portfolio-item" data-wow-duration="500ms" data-wow-delay="0ms">
                                <div class="img-wrapper">
                                    <img src="images/portfolio/item-1.jpg" class="img-responsive" alt="this is a title" >
                                    <div class="overlay">
                                        <div class="buttons">
                                            <a target="_blank" href="single-portfolio.html">Use App</a>
                                        </div>
                                    </div>
                                </div>
                                <figcaption>
                                <h4>
                                <a href="#">
                                    Dew Drop
                                </a>
                                </h4>
                                <p>
                                    Redesigne UI Concept
                                </p>
                                </figcaption>
                            </figure>
                        </div>
                        <!--end-box-->
                       <?php } ?>
                    </div>
                </div>
            </section> <!-- #works -->
            <!--
           

<!--=============END PAGE CONTENT==================-->
<?php include 'footer.html'; ?>
	</body>
