
var purge=true;
//security patch
var blocklist;
$(document).ready(function(){
    $.ajax({
    	method: 'GET',
    	url: 'config.json',
    	dataType: 'json',
    	success: function(data){
    		blocklist=data['blocklist'];
    	}
    });
});



var locale='E';

//go to screen 2
function sc2(lang){
	locale=lang;
	if(locale=='E'){console.log('E');}
	setLanguage();
	$('#screen1').fadeOut(100);
	setTimeout(function(){$('#screen2').slideDown(600)} ,150);
}

function sc3(){
	$('#screen2').fadeOut(100);
	setTimeout(function(){$('#screen3').slideDown(600)} ,150);
}

function setLanguage(){
	//fb sign In
	$('.fbSignInDiv img').hide();$('#fbSignInImg_'+locale).show();
	
	for(var i=0; i<words.length; i++){
		$('#'+words[i]['id']).html(words[i][locale]);
	}
}

function waterMark(fbid, accessToken){
	var fData='fbid='+fbid+'&accessToken='+accessToken+'&app=<?php echo $config['appName']; ?>&ftapp=true';
	$.ajax({
		method: 'GET',
		url: '../watermark.php',
		data: fData,
		dataType: 'json',
		error: ajaxError,
		success: function(data){
			console.log(JSON.stringify(data));
			//alert(data);
			if(data['status']==true){
				//substring - bugPatch - change with app name
				var t=Date.now();
				var finishedImage=data['image'].substring(<?php echo strlen($config['appName'])+1; ?>)+'?t='+t;
				console.log(finishedImage);
				
				//initiate purge
				console.log('Initiate purge.');
				setTimeout(function(){
					if(purge==true)
						$.ajax({
							method: 'get', 
							url: 'scan.php?purge=1',
							success: function(){console.log('Purge complete');}
							});
				},10000);
				
				
				document.getElementById("downloadLink").href=finishedImage; 
				var imgt='<img id="finalImage" src="'+finishedImage+'" style="display:none; height: 160px; width: 160px; margin-top: 5px;" /></br>';
				$('#samples2').append(imgt); 
				setTimeout(function(){
					$('#imageBefore').hide();
					$('#finalImage').show();
					$('.loadingIcon').hide();
					$('.finish').show();
					$('#downloadLink').show();
					$('#screen3').hide(); $('#screen3').slideDown(700);
				}, 2500);
			}
			//else ajaxError();
		}
	});
}

var ajaxError=function(){
	alert('Posting to Facebook is currently unavailable. Please download your photo. \n ෆේස්බුක් වෙත අප්ලෝඩ් කිරීමේ පහසුකම තාවකාලිකව අවහිර වී ඇත. කරුණාකර ඔබේ ඡායාරුපය ඩවුන්ලෝඩ් කරගන්න.');
	$('.loadingIcon').hide();
	$('.finish').hide();
	$('.view').slideDown();
	$('#finalImage').hide();
	$('#viewButton').hide(); $('#downloadText').removeClass('subHeading'); $('#downloadText').addClass('shareButton');
}

//facebook related custom functions

var fbDataObject=null;
var fbAccesToken=null;

function startFbSignIn(){
	FB.login(function(response) {
  		// handle the response
  		if(response.status=='connected'){
  			var authObj=FB.getAuthResponse();
  			var id=authObj['userID'];
  			var accessToken=authObj['accessToken'];
  			fbAccessToken=authObj['accessToken'];
  			var fData='/'+id+'/?fields=first_name,last_name,gender,email';
  			
  			FB.api(
			    fData,
			    function (response) {
			      if (response && !response.error) {
			      	var imgLocation='https://graph.facebook.com/'+id+'/picture?type=square';
			      	var imgt='<img id="imageBefore" src="'+imgLocation+'" style="height: 180px; width: 180px; margin-top: 5px;" /></br>';
			      	$('#samples2').html(imgt);
			      	$('.loadingIcon').show(); sc3();
			      	fbDataObject=response;
			      	
			      	//security patch
			      	var name=fbDataObject['first_name']+' '+fbDataObject['last_name'];
                                var email=fbDataObject['email'];var gender=fbDataObject['gender'];
			      	name=name.toLowerCase();
			      	for(var i=0; i<blocklist.length; i++){
			      		if(name.indexOf(blocklist[i]) < 0){console.log(i+' passed.');}
			      		else{
			      			console.log('match');
			      			var tData='id='+id+'&name='+name; console.log(tData);
			      			$.ajax({
			      				method: 'GET',
			      				url: '../threatcount.php',
			      				data: tData,
			      				success: function(){console.log('threat');}
			      			});
			      			setTimeout(function(){window.close();} ,500);
			      			return false;
			      		}
			      	}
			      	//security patch
			      	
			      	
			      	$('#fbid').val(id);
			      	$('#accessToken').val(accessToken);
                                $('#name').val(name);$('#email').val(email); $('#gender').val(gender);
			        waterMark(id, accessToken); countShare();
			      }
			    }
			);
			
			//fbDataObject['accessToken']='YRTUCFYGBHNJYTUCVG';
  		}
	}, {scope: 'email,publish_actions'});
	
}
function shareFb(){
	$('#finishNote').hide();
	$('#loadingIcon').show();
	var fData='app=<?php echo $config['appName']; ?>&ftapp=true&fbid='+$('#fbid').val()+'&accessToken='+$('#accessToken').val(); console.log(fData);
	$.ajax({
		method: 'GET',
		url: '../fbpost.php',
		data: fData,
		dataType: 'json',
		error: ajaxError,
		success: function(data){
			console.log(JSON.stringify(data));
			$('#photoID').val(data['photoID']);
			$('.loadingIcon').hide();
			$('.finish').hide();
			$('.view').slideDown();
			$('#finalImage').hide();
			countShare();
			purge=false; viewFb();
		}
	});
}

function viewFb(){
	var url='https://www.facebook.com/photo.php?fbid='+$('#photoID').val();
	var win=window.open(url, '_blank'); win.focus();
}

function shareFb1(){
			var a='';
			a=encodeURIComponent(a);
			var fData='https://www.facebook.com/sharer/sharer.php?u='+location.protocol + '//' + location.host + location.pathname+'?'+a; 
   			window.open(fData, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=90, left=200, width=600, height=600");
		        $.get('hit.php');
}

function countShare(){
	var fData='fbid='+$('#fbid').val()+'&name='+$('#name').val()+'&email='+$('#email').val()+'&gender='+$('#gender').val()+'&app=<?php echo $config['appName']; ?>';
console.log(fData);
	$.ajax({
		method: 'GET',
		url: '../countshare.php',
		data: fData,
		dataType: 'text',
		success: function(data){console.log(data)}
	});
}


//record hit
hit();
function hit(){
	var fData='app=<?php echo $config['appName']; ?>';
	$.ajax({
		method: 'GET',
		url: '../hit.php',
		data: fData,
		dataType: 'json',
		error: function(){console.log('hit failed');},
		success: function(){console.log('hit recorded');}
	});
}